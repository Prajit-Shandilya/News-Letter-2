import firebase from 'firebase';

 var firebaseConfig = {
    apiKey: "AIzaSyDzR3iGJpgmBlEgKul4l7G7whdvPsuqmC4",
  authDomain: "newsletter3-fc0a4.firebaseapp.com",
  databaseURL: "https://newsletter3-fc0a4-default-rtdb.firebaseio.com",
  projectId: "newsletter3-fc0a4",
  storageBucket: "newsletter3-fc0a4.appspot.com",
  messagingSenderId: "557422120801",
  appId: "1:557422120801:web:93f9f2592fc1cecd1cbf20"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  
  export default firebase.database();